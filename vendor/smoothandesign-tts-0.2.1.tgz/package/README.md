# smoothandesign-tts

Brique **TTS réutilisable** Smooth & Design. Voix off / narration pour n'importe
quel projet Node (Next.js, Firebase Functions, Remotion…).

- **Voix Google Cloud TTS** (`fr-FR-Neural2-D`) — « plus que correcte » et
  **gratuite dans le quota Google** (≈ 1M caractères/mois Neural2).
- **Dictionnaire de prononciation par projet** injecté en **SSML `<phoneme>` IPA**
  (approche officielle scopée — pas de substitution texte naïve qui fait bégayer).
- **Fallback ElevenLabs** optionnel (payant).
- **Framework-agnostic**, 1 seule dépendance (`@google-cloud/text-to-speech`).

## Usage

```ts
import { synthGoogleTts } from "smoothandesign-tts";

// Le dico vit DANS le projet consommateur (marques du projet).
const DICT = { UZME: "juzmi", "Cook and Perf": "kʊk ænd pɛʁf" };

const mp3: Buffer = await synthGoogleTts(
  "Découvre UZME, propulsé par Cook and Perf.",
  { pronunciation: DICT },
);
// → écris le Buffer où tu veux (Storage, fichier, réponse HTTP…)
```

Options : `voice`, `languageCode`, `speakingRate`, `pronunciation`, `client`
(injectable pour tests / réutilisation d'instance).

### SSML seul (si tu synthétises ailleurs)

```ts
import { toSsml } from "smoothandesign-tts";
toSsml("Découvre UZME", { UZME: "juzmi" });
// <speak>Découvre <phoneme alphabet="ipa" ph="juzmi">UZME</phoneme></speak>
```

### ElevenLabs (secours payant)

```ts
import { synthElevenLabs } from "smoothandesign-tts";
await synthElevenLabs("Bonjour", { apiKey, voiceId });
```

## Pourquoi SSML `<phoneme>` et pas une map de substitution ?

Les respellings naïfs (`UZME → "Youzmi"`) forcent le moteur à lire des
non-mots → **bégaiement / artefacts**. Le `<phoneme alphabet="ipa">` est honoré
par Google Neural2 et `eleven_multilingual_v2`, scopé au mot, sans toucher le
texte affiché ni l'alignement des sous-titres. Leçon apprise sur GEN MOTION.

## Coût

Google Cloud TTS Neural2 : **gratuit** jusqu'à ~1M caractères/mois, puis
~16 $ / M caractères. Pour de la narration produit, on reste quasi toujours
dans le quota gratuit.

## Dev

```bash
npm install
npm test      # vitest (SSML + synth avec client injecté)
npm run build # tsc → dist/
```

Consommé par : GEN MOTION (backend voix `google`), et prochainement
handicap-vaillant, Performance Academy.
